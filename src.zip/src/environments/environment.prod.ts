export const environment: {production: boolean} = {
  production: true,
};
